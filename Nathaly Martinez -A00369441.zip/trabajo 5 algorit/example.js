/*let someWordsToTest = ["compañeros", "estudiantes", "señores", "amigos" ,  "graduandos" ,  "artistas" ,  "universitarios"];

function lastVocalReplacer (palabras) {
    const palabraLength = palabras.length;
    for (let i = 0; i < palabraLength; i++) {
    const random = Math.random()*palabraLength;
    const randomIndex= Math.round(random);
    console.log(randomIndex)
    }
}*/

/* 1. Dada una cadena de texto (string) separe y muestre en consola los caracteres de forma desordenada uno por línea, 1 caracter a la vez.*/
function  Cortapalabras (palabra) {
    const palabraLength = palabra.length;
    const indexx = [];
    for (let i = 0; i < palabraLength; i++){
        let esIndex = true;
        
    while (esIndex){
            let random = Math.random()*(palabraLength-1);
            let randomIndex = Math.round(random);

            if(indexx.includes(randomIndex)){
                random= Math.random()*(palabraLength-1);
                randomIndex= Math.round(random);
            } else {
                indexx.push(randomIndex)
                esIndex = false;
            }
        }
        //console.log(indexx)
        console.log(palabra[indexx [i] ])
        }
    }
        Cortapalabras("esternocleidomastoideo")

/* 2. Dado un string buscar en un listado e indicar si se encuentra o no
ahí contenido, debe soportar mayúsculas y minúsculas sin importar
la variación, es lo mismo Carro, CARRO o carro.*/

    