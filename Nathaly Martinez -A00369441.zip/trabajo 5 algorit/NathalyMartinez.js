'uso estricto'

/* 1. Dada una cadena de texto (string) separe y muestre en consola los caracteres de forma desordenada uno por línea, 1 caracter a la vez.*/

let  testWord  =  "esternocleidomastoideo" ;
function  Cortapalabras ( palabra )  {
   // :)
}
Cortapalabras ( palabra de prueba ) ;

/* 2. Dado un string buscar en un listado e indicar si se encuentra o no
ahí contenido, debe soportar mayúsculas y minúsculas sin importar
la variación, es lo mismo Carro, CARRO o carro.*/

let  testTargetWordA  =  "Sabrosura" ;
let  testTargetWordB  =  "Sazón" ;
let  testTargetWordC  =  "Tempurado" ;
let  testWordsList  =  [
    "Sabr0sura" ,
    "Gozadera" ,
    "ritmo" ,
    "TEMPURADO" ,
    "SAZÓN" ,
    "Chévere" ,
    "Meneo" ,
] ;

// prueba para cada palabra A, B y C
function  buscadordepalabrasIgnorarCase ( palabraobjetivo ,  listapalabras )  {
   // :)
}



/* 3. Dado un arreglo de cuerdas, devolver la palabra más larga,
la mas corta y el tamano promedio, el arreglo debe ser
entregado por parametro y puede variar en cantidad de palabras
del arreglo de entrada libremente, debe retornar un objeto
con los valores perdidos*/

let  testSampleList  =  [
    "Capitán" ,
    "Comandante" ,
    "Teniente" ,
    "Cabo" ,
    "brigadier" ,
    "Coronel" ,
    "zar" ,
] ;

función  clasificadorlongitudpalabras ( listapalabras ) { 
    // :)
}


/* 4. Dado un string regresa si este es o no un palíndromo. No debe diferenciar entre mayúsculas y minúsculas*/

let  onVerificationWordA  =  "reconocer" ;
let  onVerificationWordB  =  "querer" ;
let  onVerificationWordC  =  "Gomosos" ;
let  onVerificationWordD  =  "Somos" ;

función  palindromeVerifier ( palabra )  {
   // :)
}


/* 5. Dado un objeto que contiene una lista de palabras contar el
número de letras vocales y consonantes y retornarlo en un arreglo de 2 posiciones.*/
let  containerTestObject  =  {
    lista : [ "Cumbamba" ,  "Oreja" ,  "Nariz" ,  "Ojo" ,  "Lengua" ,  "Diente" ]
}
function  contadordecartas ( objetoContenedor ) { 
   // :)
}


/* 6. Dado 2 arreglos de strings retornar un arreglo con todos los strings.*/
let  wordArrayA  =  [ "hola" ,  "¿"  , "cómo" ,  "estás" ,  "?" ] ;
let  wordArrayB  =  [ "te" ,  "ves"  , "igual" ,  "te" ,  "ves" ,  "igual" ] ;

función  arrayJoiner ( listaA ,  listaB )  {
 // :)
}


/* 7. Dado un arreglo de strings indicar qué posiciones del arreglo
son anagramas de una palabra base (recibida como parámetro), devuelve las posiciones en un arreglo.*/

let  probarPalabraParaExplorar  =  "amar" ;
let  wordsToVerify  =  [ "amar" ,  "arma" ,  "rana"  ,  "mara" ,  "rama" ,  "roma" ,  "amor" ,  "ramon" ,  "omar" ] ;

function  anagramaVerificador ( palabraParaExplorar ,  listaDePalabras )  {
   // :)
}

/* 8. Dado un objeto que contiene 2 arreglos, retornar un objeto con 1
arreglo que contiene las palabras sin vocales.*/

let  testObjMultiContainer  =  {
    listA : [ "piraña" ,  "cachama" ,  "tilapia" ,  "trucha" ,  "carpa" ,  "salmón" ] ,
    listaB : [ "rinoceronte" ,  "elefante" ,  "jirafa" ,  "tigre" , "gacela  " ,  "ñú" ]
} ;

function  vocalsRemoverFromObject ( objectMultiContainer )  {
    // :)
}

consola _ registro ( vocalsRemoverFromObject ( testObjMultiContainer ) ) ;

/* 9. Dado un arreglo de palabras reemplazando la última voz por una xy devolver dicho arreglo.*/

let  someWordsToTest  =  [ "compañeros" ,  "estudiantes" ,  "señores" ,  "amigos" ,  "graduandos" ,  "artistas" ,  "universitarios" ] ;

función  lastVocalReplacer ( palabras )  {
    // :)
}


/* 10. Dada una lista de palabras verificar si alguna de las palabras es la
version al revés de alguna de las palabras de una segunda lista,
debe contar las identificaciones y devolver un objeto con ese contenido.*/


let  testListA  =  [ "amor" ,  "sabor" ,  "calor" , "firma" ,  "mara" ] ;
let  testListB  =  [ "roma" ,  "robar" ,  "portar" ,  "arma" ,  "mora" ] ;

function  doubleListVerifier ( listaA ,  listaB )  {
    // :)
}